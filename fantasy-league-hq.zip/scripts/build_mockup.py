#!/usr/bin/env python3
"""Builds mockups/league-hq.html — the light-mode league state page.

Nothing here touches the Yahoo API. Every league, team, manager and player name
below is invented, and the headshots are generated silhouettes, so the repository
ships no Yahoo Fantasy Sports data and no third-party imagery.
"""

import hashlib
import pathlib

OUT = pathlib.Path(__file__).resolve().parent.parent / "mockups"

LEAGUE = {"name": "The Gordie Howe Memorial League", "season": "2026-27",
          "week": 9, "teams": 12, "scoring": "Head-to-head, 12 teams",
          "updated": "Saturday 10:42 AM"}

# rank, team, manager, W, L, T, PF, PA, streak, last5
STANDINGS = [
    (1, "Top Shelf Tacticians", "Olivia D.", 7, 1, 0, 612.4, 498.2, "W4", "WWWWL"),
    (2, "Blue Line Bandits", "Marcus P.", 6, 2, 0, 588.1, 521.7, "W2", "WWLWW"),
    (3, "Wet Bandits", "Foster S.", 6, 2, 0, 571.9, 530.4, "L1", "LWWWW"),
    (4, "Gritty Committee", "Jordan R.", 5, 3, 0, 559.6, 540.1, "W1", "WLWLW"),
    (5, "Rust Belt Rovers", "Dana M.", 5, 3, 0, 544.8, 536.9, "W3", "WWWLL"),
    (6, "Five Hole Fillers", "Nina B.", 4, 4, 0, 531.2, 529.8, "L2", "LLWWL"),
    (7, "Third Line Heroes", "Tom C.", 4, 4, 0, 528.7, 544.3, "W1", "WLLWL"),
    (8, "Sons of Pitches", "Amir K.", 4, 4, 0, 519.3, 551.0, "L1", "LWLWL"),
    (9, "Icing on the Cake", "Kiera V.", 3, 5, 0, 502.6, 558.4, "L3", "LLLWW"),
    (10, "Backdoor Sliders", "Eli W.", 3, 5, 0, 497.1, 561.2, "W1", "WLLLW"),
    (11, "Couch Potatoes", "Ravi L.", 2, 6, 0, 468.9, 579.6, "L5", "LLLLL"),
    (12, "Last Pick Larry", "Sam G.", 1, 7, 0, 441.3, 592.8, "L6", "LLLLL"),
]
PLAYOFF_CUT = 6

MATCHUPS = [
    ("Top Shelf Tacticians", 74.2, "Couch Potatoes", 51.8),
    ("Blue Line Bandits", 68.9, "Last Pick Larry", 44.1),
    ("Icing on the Cake", 61.7, "Wet Bandits", 59.3),
    ("Gritty Committee", 55.0, "Backdoor Sliders", 54.6),
    ("Rust Belt Rovers", 71.4, "Sons of Pitches", 48.2),
    ("Third Line Heroes", 66.5, "Five Hole Fillers", 62.8),
]

TRADES = [
    {"status": "pending", "when": "Proposed 18h ago", "note": "3 of 12 votes to veto &middot; 18h left",
     "a": ("Icing on the Cake", [("R. Mbeki", "C &middot; MIN"), ("A. Holmqvist", "D &middot; VAN")]),
     "b": ("Couch Potatoes", [("N. Cisneros", "RW &middot; NSH")])},
    {"status": "pending", "when": "Proposed 2d ago", "note": "0 of 12 votes to veto &middot; 2d left",
     "a": ("Sons of Pitches", [("J. Owusu", "G &middot; OTT")]),
     "b": ("Backdoor Sliders", [("W. Petrosyan", "LW &middot; DET")])},
    {"status": "accepted", "when": "Completed 3h ago", "note": "Passed league review",
     "a": ("Rust Belt Rovers", [("D. Falkenrath", "C &middot; STL")]),
     "b": ("Five Hole Fillers", [("M. Nwachukwu", "D &middot; SEA"), ("L. Bergeron", "RW &middot; BUF")])},
    {"status": "vetoed", "when": "Rejected Tuesday", "note": "7 of 12 votes to veto",
     "a": ("Last Pick Larry", [("T. Okafor", "C &middot; PIT")]),
     "b": ("Top Shelf Tacticians", [("C. Waldstein", "LW &middot; WSH")])},
]

TRANSACTIONS = [
    ("add", "Blue Line Bandits", "R. Mbeki", "C &middot; MIN", "12m"),
    ("drop", "Blue Line Bandits", "H. Ravenscroft", "D &middot; ANA", "12m"),
    ("add", "Third Line Heroes", "J. Owusu", "G &middot; OTT", "1h"),
    ("drop", "Icing on the Cake", "P. Sarmiento", "RW &middot; CBJ", "5h"),
    ("add", "Wet Bandits", "T. Okafor", "C &middot; PIT", "9h"),
    ("add", "Gritty Committee", "C. Waldstein", "LW &middot; WSH", "14h"),
    ("drop", "Couch Potatoes", "B. Nakashima", "G &middot; PHI", "1d"),
]

WAIVERS = ["Last Pick Larry", "Couch Potatoes", "Backdoor Sliders", "Icing on the Cake",
           "Sons of Pitches", "Third Line Heroes", "Five Hole Fillers", "Rust Belt Rovers"]


def headshot(seed):
    h = int(hashlib.md5(seed.encode()).hexdigest()[:6], 16)
    hue = h % 360
    return ("data:image/svg+xml;utf8,"
            "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>"
            "<defs><clipPath id='c'><circle cx='32' cy='32' r='32'/></clipPath></defs>"
            "<g clip-path='url(%23c)'>"
            f"<rect width='64' height='64' fill='hsl({hue},38%,88%)'/>"
            f"<circle cx='32' cy='25' r='12' fill='hsl({hue},30%,58%)'/>"
            f"<ellipse cx='32' cy='61' rx='21' ry='20' fill='hsl({hue},32%,68%)'/>"
            "</g></svg>")


CSS = """
:root{
  --page:#EEF1F6; --card:#FFFFFF; --edge:#D7DEE9; --hair:#E8EDF4;
  --ink:#0E1F38; --mute:#5F7390; --faint:#8295AE;
  --blue:#1F5FD0; --red:#C8102E; --green:#0C7A5B; --amber:#B4761A;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--page);color:var(--ink);width:1600px;
  font-family:"TeX Gyre Heros","Helvetica Neue",Arial,sans-serif}
.cn{font-family:"TeX Gyre Heros Cn","DejaVu Sans Condensed",Arial,sans-serif}
.mast-name{font-family:"Bitstream Charter","Charter",Georgia,serif}

.mast{background:var(--card);border-bottom:3px solid var(--ink);
  padding:22px 40px 18px;display:flex;align-items:flex-end;gap:28px}
.mast .lede{flex:1;min-width:0}
.mast .kick{font-size:11px;letter-spacing:.17em;color:var(--blue);font-weight:700;
  margin-bottom:7px}
.mast h1{font-size:38px;line-height:1;font-weight:700;letter-spacing:-.01em}
.mast .sub{font-size:13px;color:var(--mute);margin-top:8px}
.mast .wk{text-align:right;flex:0 0 auto;padding-left:28px;border-left:1px solid var(--edge)}
.mast .wk .n{font-size:46px;font-weight:700;line-height:1}
.mast .wk .l{font-size:11px;letter-spacing:.14em;color:var(--mute);margin-top:2px}

.wrap{padding:24px 40px 40px;display:grid;grid-template-columns:repeat(12,1fr);
  gap:20px;align-items:start}
.card{background:var(--card);border:1px solid var(--edge);border-radius:7px;
  padding:20px 22px 18px}
.c7{grid-column:span 7} .c5{grid-column:span 5}
.hd{display:flex;align-items:baseline;gap:12px;margin-bottom:3px}
.hd h2{font-size:19px;font-weight:700}
.hd .note{font-size:11.5px;color:var(--faint);margin-left:auto}
.sub2{font-size:12px;color:var(--mute);margin-bottom:15px}

table{width:100%;border-collapse:collapse}
th{font-size:10px;letter-spacing:.09em;color:var(--faint);text-align:left;font-weight:700;
  padding:0 6px 8px;border-bottom:1.5px solid var(--ink)}
th.r,td.r{text-align:right}
td{padding:7px 6px;border-bottom:1px solid var(--hair);font-size:13.5px}
td.rk{color:var(--faint);font-size:11.5px;width:20px}
td.tm{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:170px}
td.tm small{display:block;color:var(--mute);font-weight:400;font-size:10.5px;margin-top:1px}
td.rec{font-weight:700;white-space:nowrap}
td.num{color:var(--mute);font-size:12.5px;font-variant-numeric:tabular-nums}
tr.me td{background:#F3F7FF}
tr.cut td{border-bottom:2px solid var(--blue)}
.strk{font-size:11px;font-weight:700}
.strk.w{color:var(--green)} .strk.l{color:var(--red)}
.form{display:inline-flex;gap:2.5px}
.form i{width:8px;height:14px;border-radius:2px;display:block}
.form i.w{background:var(--green)} .form i.l{background:#E3B6BE}
.cutline{font-size:10px;letter-spacing:.1em;color:var(--blue);font-weight:700;padding:9px 6px 0}

.mu{padding:11px 0;border-bottom:1px solid var(--hair)}
.mu:last-child{border-bottom:none}
.mu .side{display:flex;align-items:center;gap:10px;padding:3px 0}
.mu .nm{flex:1;font-size:13.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mu .sc{font-size:16px;font-weight:700;width:58px;text-align:right;
  font-variant-numeric:tabular-nums}
.mu .lead .nm{font-weight:700}
.mu .trail .nm,.mu .trail .sc{color:var(--faint)}
.mu .bar{height:3px;background:var(--hair);border-radius:2px;margin-top:8px;overflow:hidden}
.mu .bar i{display:block;height:100%;background:var(--blue)}

.tr{border:1px solid var(--edge);border-radius:6px;padding:13px 15px;margin-bottom:11px}
.tr:last-child{margin-bottom:0}
.tr .top{display:flex;align-items:center;gap:10px;margin-bottom:11px}
.tr .pill{font-size:10px;font-weight:700;letter-spacing:.09em;padding:3px 8px;border-radius:3px}
.tr.pending .pill{background:#FDF2DC;color:var(--amber)}
.tr.accepted .pill{background:#E3F4ED;color:var(--green)}
.tr.vetoed .pill{background:#FBE9EC;color:var(--red)}
.tr .when{font-size:11.5px;color:var(--mute)}
.tr .note{font-size:11.5px;color:var(--faint);margin-left:auto}
.tr .deal{display:grid;grid-template-columns:1fr 34px 1fr;gap:10px;align-items:start}
.tr .team{font-size:11px;color:var(--mute);margin-bottom:7px;white-space:nowrap;
  overflow:hidden;text-overflow:ellipsis}
.tr .arrow{text-align:center;color:var(--faint);font-size:17px;align-self:center}
.tr .pl{display:flex;align-items:center;gap:8px;padding:3.5px 0}
.tr .pl img{width:26px;height:26px;border-radius:50%;flex:0 0 26px;
  border:1px solid var(--edge)}
.tr .pl .n{font-size:13px;font-weight:700;line-height:1.2;min-width:0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tr .pl .m{font-size:10.5px;color:var(--mute)}

.tx{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--hair)}
.tx:last-child{border-bottom:none}
.tx img{width:28px;height:28px;border-radius:50%;flex:0 0 28px;border:1px solid var(--edge)}
.tx .vb{font-size:9.5px;font-weight:700;letter-spacing:.07em;padding:2px 6px;border-radius:3px;
  flex:0 0 auto}
.tx.add .vb{background:#E3F4ED;color:var(--green)}
.tx.drop .vb{background:#FBE9EC;color:var(--red)}
.tx .body{min-width:0;flex:1}
.tx .n{font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tx .m{font-size:10.5px;color:var(--mute);white-space:nowrap;overflow:hidden;
  text-overflow:ellipsis}
.tx .ago{font-size:11px;color:var(--faint);flex:0 0 auto}

.wv{display:flex;align-items:center;gap:11px;padding:7px 0;border-bottom:1px solid var(--hair);
  font-size:13px}
.wv:last-child{border-bottom:none}
.wv .n{color:var(--faint);font-size:11px;width:16px;font-weight:700}
.wv .t{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.stack > .card + .card{margin-top:20px}
.stack{grid-column:span 5;display:block}
"""


def mast():
    return f"""<div class="mast">
  <div class="lede">
    <div class="kick">LEAGUE HOME &middot; {LEAGUE['season']}</div>
    <h1 class="mast-name">{LEAGUE['name']}</h1>
    <div class="sub">{LEAGUE['scoring']} &middot; Updated {LEAGUE['updated']}</div>
  </div>
  <div class="wk"><div class="n cn">{LEAGUE['week']}</div><div class="l">WEEK</div></div>
</div>"""


def standings():
    rows = []
    for rk, tm, mg, w, l, t, pf, pa, strk, last5 in STANDINGS:
        cls = []
        if rk == PLAYOFF_CUT:
            cls.append("cut")
        if mg == "Foster S.":
            cls.append("me")
        c = f' class="{" ".join(cls)}"' if cls else ""
        form = "".join(f'<i class="{r.lower()}"></i>' for r in last5)
        sc = "w" if strk.startswith("W") else "l"
        rows.append(
            f'<tr{c}><td class="rk cn">{rk}</td>'
            f'<td class="tm">{tm}<small>{mg}</small></td>'
            f'<td class="rec cn">{w}-{l}-{t}</td>'
            f'<td class="num r">{pf:.1f}</td><td class="num r">{pa:.1f}</td>'
            f'<td class="num r">{pf - pa:+.1f}</td>'
            f'<td class="r"><span class="strk {sc}">{strk}</span></td>'
            f'<td class="r"><span class="form">{form}</span></td></tr>')
    return f"""<div class="card c7">
  <div class="hd"><h2>Standings</h2><span class="note">Through week {LEAGUE['week'] - 1}</span></div>
  <div class="sub2">Top {PLAYOFF_CUT} make the playoffs. Form runs oldest to newest.</div>
  <table><thead><tr><th></th><th>TEAM</th><th>REC</th><th class="r">PF</th>
    <th class="r">PA</th><th class="r">DIFF</th><th class="r">STRK</th>
    <th class="r">LAST 5</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
  <div class="cutline">PLAYOFF CUT LINE</div>
</div>"""


def matchups():
    out = []
    for a, sa, b, sb in MATCHUPS:
        total = sa + sb
        pct = round(sa / total * 100)
        out.append(
            f'<div class="mu">'
            f'<div class="side lead"><span class="nm">{a}</span>'
            f'<span class="sc cn">{sa:.1f}</span></div>'
            f'<div class="side trail"><span class="nm">{b}</span>'
            f'<span class="sc cn">{sb:.1f}</span></div>'
            f'<div class="bar"><i style="width:{pct}%"></i></div></div>')
    return f"""<div class="card c5">
  <div class="hd"><h2>Week {LEAGUE['week']}</h2><span class="note">Live</span></div>
  <div class="sub2">Scoring in progress &mdash; leader shown on top</div>
  {''.join(out)}
</div>"""


def side(team, players):
    rows = "".join(
        f'<div class="pl"><img src="{headshot(n)}" alt="">'
        f'<div style="min-width:0"><div class="n">{n}</div>'
        f'<div class="m">{m}</div></div></div>'
        for n, m in players)
    return f'<div><div class="team">{team} sends</div>{rows}</div>'


def trades():
    out = []
    for t in TRADES:
        out.append(
            f'<div class="tr {t["status"]}">'
            f'<div class="top"><span class="pill">{t["status"].upper()}</span>'
            f'<span class="when">{t["when"]}</span>'
            f'<span class="note">{t["note"]}</span></div>'
            f'<div class="deal">{side(*t["a"])}'
            f'<div class="arrow">&harr;</div>{side(*t["b"])}</div></div>')
    pending = sum(1 for t in TRADES if t["status"] == "pending")
    return f"""<div class="card c7">
  <div class="hd"><h2>Trades</h2>
    <span class="note">{pending} awaiting league review</span></div>
  <div class="sub2">Pending trades first, then everything settled this week</div>
  {''.join(out)}
</div>"""


def rail():
    tx = "".join(
        f'<div class="tx {k}"><img src="{headshot(p)}" alt="">'
        f'<span class="vb">{k.upper()}</span>'
        f'<div class="body"><div class="n">{p}</div>'
        f'<div class="m">{m} &middot; {tm}</div></div>'
        f'<span class="ago">{ago}</span></div>'
        for k, tm, p, m, ago in TRANSACTIONS)

    wv = "".join(f'<div class="wv"><span class="n cn">{i}</span>'
                 f'<span class="t">{t}</span></div>'
                 for i, t in enumerate(WAIVERS, start=1))

    return f"""<div class="stack">
  <div class="card">
    <div class="hd"><h2>Recent moves</h2></div>
    <div class="sub2">Adds and drops across all twelve teams</div>{tx}
  </div>
  <div class="card">
    <div class="hd"><h2>Waiver priority</h2></div>
    <div class="sub2">Reverse standings order &mdash; resets after each claim</div>{wv}
  </div>
</div>"""


def build():
    body = (mast() + '<div class="wrap">'
            + standings() + matchups() + trades() + rail() + '</div>')
    html = (f'<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8">\n'
            f'<title>{LEAGUE["name"]} &mdash; League home</title>\n'
            f'<style>{CSS}</style>\n</head><body>\n{body}\n</body></html>\n')
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "league-hq.html").write_text(html)
    print("wrote", OUT / "league-hq.html")


if __name__ == "__main__":
    build()
